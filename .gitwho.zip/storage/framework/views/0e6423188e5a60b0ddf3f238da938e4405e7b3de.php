<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <link rel="stylesheet" type="text/css" href="http://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!--     Fonts and icons     -->

    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">    
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/voucher.css')); ?>">    

</head>
<body style="background-color: #473C70;">
 
 <div class="offset-xl-2 col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12 padding">
     <div class="card printableArea shadow">
         <div class="card-header p-4">
             <a class="pt-2 d-inline-block" href="index.html" data-abc="true">Wai Hin Oo Mobile</a>
             <div class="float-right">
                 <h3 class="mb-0">Invoice #<?php echo e($voucher->voucher_number); ?></h3>
                 Date: <?php echo e($voucher->date); ?>

             </div>
         </div>
         <div class="card-body">
             <div class="row mb-4">
                 <div class="col-sm-6">
                     <h3 class="text-dark mb-1">Wai Hin Oo</h3>
                     <div>Thamine</div>
                     <div>Yangon</div>
                     <div>Email: waihinoo342@gmail.com</div>
                     <div>Phone: 0950000000</div>
                 </div>
             </div>
             <div class="table-responsive-sm">
                 <table class="table table-striped">
                     <thead>
                         <tr>
                             <th  style="text-align: center;">IMEI/Model</th>
                             <th  style="text-align: center;">Name</th>
                             <th  style="text-align: center;"></th>
                             <th  style="text-align: center;"></th>
                             <th  style="text-align: center;">Price</th>
                             <th  style="text-align: center;">Qty</th>
                             <th style="text-align: center;">Total</th>
                         </tr>
                     </thead>
                     <tbody>
                        <?php $i=1; ?>
                        <?php if( $voucher->item_list != null ): ?>
                        <?php $__currentLoopData = $voucher->item_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                             <td style="text-align: center;"><?php echo e($item_list->imei_number); ?></td>
                             <td style="text-align: center;" class="left strong"><?php echo e($item_list->name); ?></td>
                             
                             <td style="text-align: center;"></td>
                             <td style="text-align: center;"></td>
                             <td style="text-align: center;" class="right"><?php echo e($item_list->selling_price); ?></td>
                             <td style="text-align: center;" class="center"><?php echo e($item_list->order_qty); ?></td>
                             <td style="text-align: center;" class="right"><?php echo e($item_list->selling_price * $item_list->order_qty); ?></td>
                         </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php endif; ?>

                         <?php if( $voucher->accessory_list != null ): ?>
                         <?php $__currentLoopData = $voucher->accessory_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accessory_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                             <td style="text-align: center;" class="center"><?php echo e($accessory_list->custom_gift); ?></td>
                             <td style="text-align: center;" class="left strong"><?php echo e($accessory_list->name); ?></td>
                             <td style="text-align: center;"></td>
                             <td style="text-align: center;"></td>
                             <td style="text-align: center;" class="right"><?php echo e($accessory_list->selling_price); ?></td>
                             <td style="text-align: center;" class="center"><?php echo e($accessory_list->order_qty); ?></td>
                             <td style="text-align: center;" class="right"><?php echo e($accessory_list->selling_price * $accessory_list->order_qty); ?></td>
                         </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php endif; ?>
                     </tbody>
                 </table>
             </div>
             <div class="row">
                 <div class="col-lg-4 col-sm-5" style="margin-left: 560px;">
                     <table class="table table-clear">
                         <tbody>
                             <tr>
                                 <td style="text-align: center;">
                                     <strong class="text-dark">Subtotal</strong>
                                 </td>
                                 <td style="text-align: center;"><?php echo e($voucher->total_amount); ?></td>
                             </tr>
                             <tr>
                                 <td style="text-align: center;">
                                     <strong class="text-dark">Discount</strong>
                                 </td>
                                 <td style="text-align: center;"><?php echo e($voucher->total_discount); ?></td>
                             </tr>
                             <tr>
                                 <td style="text-align: center;">
                                     <strong class="text-dark">Total</strong> </td>
                                 <td style="text-align: center;">
                                     <strong class="text-dark"><?php echo e($voucher->voucher_grand_total); ?></strong>
                                 </td>
                             </tr>
                         </tbody>
                     </table>
                 </div>
             </div>
         </div>
         <div class="card-footer bg-white">
             <p class="mb-0">Address Here</p>
         </div>
     </div>
     <button id="print" class="btn btn-success mb-3 mr-3 float-right btn-submit" type="button">
     Print
    </button>
 </div>

    

 <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
 <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
 <script src="<?php echo e(asset('js/jquery.PrintArea.js')); ?>" type="text/JavaScript"></script>

 <script type="text/javascript">
     $("#print").click(function() {
            var mode = 'iframe'; //popup
            var close = mode == "popup";
            var options = {
                mode: mode,
                popClose: close
            };
            $("div.printableArea").printArea(options);
        });
 </script>
</body>
</html><?php /**PATH /home/syslandmm/devmobile.syslandmm.com/resources/views/invoice.blade.php ENDPATH**/ ?>