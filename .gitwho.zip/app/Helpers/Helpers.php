<?php

	function getIntValue($sales_string){

        return intval($sales_string[0]->total); // get int value for profit array

    }

?>