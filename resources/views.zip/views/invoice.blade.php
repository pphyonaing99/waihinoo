<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <link rel="stylesheet" type="text/css" href="http://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <!--     Fonts and icons     -->

    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="{{asset('css/bootstrap.min.css')}}">    
    <link rel="stylesheet" type="text/css" href="{{asset('css/voucher.css')}}">    
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

    <style type="text/css">
        body{
            color: blue;
            -webkit-print-color-adjust:exact;
        }
        /*.card-header h2,h4{
            text-align: center;
        }*/
    </style>

</head>
<body style="background-color: #473C70;">
 
 <div class="offset-xl-2 col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12 padding">
     <div class="card printableArea shadow">
         <div class="card-header p-4">
             <h2 class="text-primary text-center">၀ေဟင်ဦး (Mobile)</h2>
             <h4 class="text-primary text-center">Sales & Service Center</h4>
             <p class="text-primary text-center">အမှတ် ၂၇၆၊ အလောင်းဘုရားလမ်းမနှင့် ၁၁လမ်းထောင့်၊ ၁ရပ်ကွက်၊မရမ်းကုန်းမြို့နယ်၊ရန်ကုန်မြို့။</p>
             <p class="text-primary text-center"><i class="fas fa-mobile-alt"></i> : 09-965100514, 09-448008522, 09-795505099</p>
         </div>
         <div class="card-body">
             <div class="row">
                 <div class="col-sm-8 py-0">
                     <p style="display: inline;">Name   ................................................................................................................................</p> 
                 </div>
                 <div class="col-sm-4 py-0">
                    <p class="float-right">Date ..................................................</p> 
                 </div>
             </div>
             <div class="row mb-4 py-0">
                 <div class="col-sm-8">
                     <p style="display: inline;">Address   .......................................................................................................................</p> 
                 </div>
                 <div class="col-sm-4 py-0">
                    <p style="display: inline;" class="float-right"><i class="fas fa-2x fa-phone-square-alt"></i> ....................................................</p> 
                 </div>
             </div>
             <div class="table-responsive-sm">
                 <table class="table table-striped" style="width: 100%;">
                     <thead>
                         <tr>
                             <th style="text-align: center;background-color: rgb(0,0,255,0.2); width: 83px;"><p>No</p><p>စဥ်</p></th>
                             <th  style="text-align: center;background-color: rgb(0,0,255,0.2); width: 250px;"><p>Particular</p><p>အမျိုးအမည်</p></th>
                             <th  style="text-align: center;background-color: rgb(0,0,255,0.2); width: 100px;"><p>Quantity</p><p>အရေအတွက်</p></th>
                             <th  style="text-align: center;background-color: rgb(0,0,255,0.2); width: 200px;"><p>Unit Price</p><p>နှုန်း</p></th>
                             <th  style="text-align: center;background-color: rgb(0,0,255,0.2); width: 200px;"><p>Amount</p><p>သင့်ငွေ</p></th>
                         </tr>
                     </thead>
                     <tbody>
                        <?php $i=1; ?>
                        @if( $voucher->item_list != null )
                        @foreach( $voucher->item_list as $item_list )
                         <tr>
                             <td style="text-align: center;">{{ $i++ }}</td>
                             <td style="text-align: center;" class="left strong">{{ $item_list->name }}</td>
                             <td style="text-align: center;" class="center">{{ $item_list->order_qty }}</td>
                             <td style="text-align: center;" class="right">{{ $item_list->selling_price }}</td>
                             <td style="text-align: center;" class="right">{{ $item_list->selling_price * $item_list->order_qty }}</td>
                         </tr>
                         @endforeach
                         @endif

                         @if( $voucher->accessory_list != null )
                         @foreach( $voucher->accessory_list as $accessory_list )
                         <tr>
                             <td style="text-align: center;" class="center">{{ $i++ }}</td>
                             <td style="text-align: center;" class="left strong">{{ $accessory_list->name }}</td>
                             <td style="text-align: center;" class="center">{{ $accessory_list->order_qty }}</td>
                             <td style="text-align: center;" class="right">{{ $accessory_list->selling_price }}</td>
                             <td style="text-align: center;" class="right">{{ $accessory_list->selling_price * $accessory_list->order_qty }}</td>
                         </tr>
                         @endforeach
                         @endif
                         <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                             <td class="text-center text-primary">
                                 <strong>Total Amount</strong>
                             </td>
                             <td class="text-center">
                                 <strong>{{ $voucher->voucher_grand_total }}</strong>
                             </td>
                         </tr>
                     </tbody>
                 </table>
             </div>
         </div>
         <div class="card-footer bg-white">
            <p><i class="fas fa-cannabis"></i> ဝယ်ယူသည့် ပစ္စည်းစမ်းသပ်စစ်ဆေးပါ</p>
            <p><i class="fas fa-cannabis"></i> ဝယ်ပြီးပစ္စည်း ငွေပြန်မအမ်းပါ</p>
            <p><i class="fas fa-cannabis"></i> အားပေးမှုကို ကျေးဇူးတင်ပါသည်</p>
             <p class="mb-0">အမှတ် ၂၇၆၊ အလောင်းဘုရားလမ်းမနှင့် ၁၁လမ်းထောင့်၊ ၁ရပ်ကွက်၊မရမ်းကုန်းမြို့နယ်၊ရန်ကုန်မြို့။</p>
         </div>
     </div>
     <button id="print" class="btn btn-success mb-3 mr-3 float-right btn-submit" type="button">
     Print
    </button>
 </div>

    

 <script src="{{asset('js/jquery.min.js')}}"></script>
 <script src="{{asset('js/bootstrap.min.js')}}"></script>
 <script src="{{asset('js/jquery.PrintArea.js')}}" type="text/JavaScript"></script>

 <script type="text/javascript">
     $("#print").click(function() {
            var mode = 'iframe'; //popup
            var close = mode == "popup";
            var options = {
                mode: mode,
                popClose: close
            };
            $("div.printableArea").printArea(options);
        });
 </script>
</body>
</html>