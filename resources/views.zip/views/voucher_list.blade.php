<link rel="stylesheet" type="text/css" href="{{asset('css/table.css')}}"> 
<link rel="stylesheet" type="text/css" href="{{asset('css/card.css')}}">
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 
<link rel="stylesheet" type="text/css" href="{{asset('css/bootstrap.min.css')}}">  
<link rel="stylesheet" type="text/css" href="{{asset('css/bootstrap.min.css')}}">  
<link rel="stylesheet" type="text/css" href="{{asset('css/dataTables.bootstrap4.css')}}">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.3.1/css/all.min.css" rel="stylesheet">



<section id="plan-features">

    <div class="row ml-2 mr-2">
        <div class="col-xl-3 col-lg-6">
            <div class="card card-stats mb-4 mb-xl-0">
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                        <h5 class="card-title text-uppercase text-muted mb-0">Total Sales</h5>
                        <span class="h2 font-weight-bold mb-0 text-dark" style="font-size: 25px;">{{ number_format($total_sales[0]->total) }} ks</span>
                    </div>
                    <div class="col-auto">
                        <div class="icon icon-shape text-white rounded-circle shadow" style="background-color:#473C70;">
                            <i class="fas fa-balance-scale"></i>
                            </div>
                        </div>
                    </div>
                    <p class="mt-3 mb-0 text-muted text-sm">
                    <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
                    <span class="text-nowrap">Since last month</span>
                    </p>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-6">
            <div class="card card-stats mb-4 mb-xl-0">
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                        <h5 class="card-title text-uppercase text-muted mb-0">Phone Sales</h5>
                        <span class="h2 font-weight-bold mb-0 text-dark" style="font-size: 25px;">{{ number_format($product_profits[0]->total) }} ks</span>
                    </div>
                    <div class="col-auto">
                        <div class="icon icon-shape text-white rounded-circle shadow" style="background-color:#473C70;">
                            <i class="fas fa-mobile"></i>
                            </div>
                        </div>
                    </div>
                    <p class="mt-3 mb-0 text-muted text-sm">
                    <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
                    <span class="text-nowrap">Since last month</span>
                    </p>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-6">
            <div class="card card-stats mb-4 mb-xl-0">
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <h5 class="card-title text-uppercase text-muted mb-0">Accessory Sales</h5>
                            <span class="h2 font-weight-bold mb-0 text-dark" style="font-size: 25px;">{{ number_format($accessory_profits[0]->total) }} ks</span>
                        </div>
                        <div class="col-auto">
                            <div class="icon icon-shape text-white rounded-circle shadow" style="background-color:#473C70;">
                                <i class="fas fa-headphones"></i>
                            </div>
                        </div>
                    </div>
                    <p class="mt-3 mb-0 text-muted text-sm">
                    <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
                    <span class="text-nowrap">Since last month</span>
                    </p>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-6">
            <div class="card card-stats mb-4 mb-xl-0">
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                        <h5 class="card-title text-uppercase text-muted mb-0">Monthly Sales</h5>
                        <span class="h2 font-weight-bold mb-0 text-dark" style="font-size: 25px;">{{ number_format($monthly_sales[0]->total) }} ks</span>
                    </div>
                    <div class="col-auto">
                        <div class="icon icon-shape text-white rounded-circle shadow" style="background-color:#473C70;">
                            <i class="fas fa-chart-bar"></i>
                            </div>
                        </div>
                    </div>
                    <p class="mt-3 mb-0 text-muted text-sm">
                    <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
                    <span class="text-nowrap">Since this month</span>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <div class="container">

        <a href=""><i class="fas fa-sync"></i></a>
        <table id="plan-matrix" class="table-zebra table-zebra-dark more-spacing">
            <thead style="color: white;">
                <tr>
                    <th style="text-align: center;" class="plan-matrix-label">Voucher Number</th>
                    <th style="text-align: center;" class="plan-matrix-details">Sold By</th>
                    <th style="text-align: center;" class="plan-matrix-details">Payment Type</th>
                    <th style="text-align: center;" class="plan-matrix-details">Total Amount</th>
                    <th style="text-align: center;" class="plan-matrix-details">Details</th>
                </tr>
            </thead>
            <tbody style="color: white;">
                @foreach($voucher_list as $voucher)
                <tr>
                    <td class="plan-matrix-label" style="text-align: center;">{{ $voucher->voucher_number }}</td>
                    <td style="text-align: center;">{{ $voucher->sold_by }}</td>
                    <td style="text-align: center;">{{ $voucher->payment_type }}</td>
                    <td style="text-align: center;">{{ $voucher->voucher_grand_total }}</td>
                    <td style="text-align: center;"><a href="{{ route('getVoucherDetails',$voucher->id) }}" class="btn btn-primary" style="color: white;">Details</a></td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</section>
 <script src="{{asset('js/jquery.min.js')}}"></script>
 <script src="{{asset('js/jquery.datatable.js')}}"></script>
 <script src="{{asset('js/bootstrap.min.js')}}"></script>
 <script src="{{asset('js/dataTables.bootstrap4.min.js')}}"></script>
 <script>
  $(document).ready( function () {
    
    $('#plan-matrix').DataTable({
        
        order: [ [0, 'desc'] ]
    })
});
</script>
